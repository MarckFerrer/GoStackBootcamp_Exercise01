const express = require("express");

const server = express();
server.use(express.json());

const project = [
  {
    id: "1",
    title: "First Project",
    tasks: "Task 01"
  }
];

function checkProjectId(req, res, next) {
  const id = req.body.index;
  if (!id) {
    return res.status(400).json({ error: "Please insert the project number" });
  }
  req.id = id;
  next();
}

function checkProjectTitle(req, res, next) {
  const title = req.body.title;
  if (!title || title === "") {
    return res.status(400).json({ error: "Please insert the project title" });
  }
  req.title = title;
  next();
}

function checkProjectTask(req, res, next) {
  tasks = req.body.tasks;

  if (!tasks) {
    return res.status(400).json({ error: "Please insert at least one task" });
  }
  req.tasks = tasks;
  next();
}

function checkProjectInArray(req, res, next) {
  const projectValue = project[req.params.index];

  if (!projectValue) {
    return res.status(400).json({ error: "The project doen't exist" });
  }
  req.project = projectValue;
  return next();
}

server.post("/projects", checkProjectId, checkProjectTitle, (req, res) => {
  project.push({ id: req.id, title: req.title });
  return res.json(project);
});

server.get("/projects", (req, res) => {
  return res.json(project);
});

server.put(
  "/projects/:index",
  checkProjectTitle,
  checkProjectInArray,
  (req, res) => {
    const { index } = req.params;
    const { title } = req.body;

    var findProject = project.find(item => item.id === index);

    findProject.title = title;
    return res.json(project);
  }
);

server.delete("/projects/:index", checkProjectInArray, (req, res) => {
  const { index } = req.params;
  project.splice(index, 1);
  return res.json(project);
});

server.post("/projects/:id/tasks", (req, res) => {
  const { id } = req.params;
  const { title } = req.body;

  const project = project.find(p => p.id === id);

  project.tasks.push(title);

  return res.json(project);
});

server.listen(3000);
